users 
id      name        email       password        

shop
id     slug     user_id     name        description


product_category
id      slug        name 

product 
id      category_id       slug        name      image       price       total_qty         sell_price                        


product_buy 
id      product_id      buy_price       total_qty 


product_sale    
id      product_id      price   
